# Deacons Service Management — Firebase Step 5

آخر نسخة محفوظة من المشروع في هذه المرحلة من تطوير نظام **Deacons Service Management**.

> **الحالة الحالية:** Step 5 — Firebase Authentication + User Profiles + Role/Class Validation
>
> **مهم:** هذه ليست النسخة النهائية للتطبيق، ولم يتم إخراج APK نهائي من هذه النسخة.

---

## 1. فكرة المشروع

التطبيق الأصلي Android/Kotlin + Jetpack Compose ويعتمد على **Room** كقاعدة بيانات محلية.

الخطة النهائية هي الحفاظ على نفس التطبيق ونفس الشاشات والوظائف، مع إضافة Firebase بحيث يصبح النظام:

- **Offline-first:** البيانات المحلية تستمر في العمل بدون إنترنت.
- **Room:** تظل قاعدة البيانات المحلية الأساسية للتشغيل اليومي.
- **Firebase:** التخزين السحابي والمزامنة المركزية.
- **Firebase Authentication:** حساب مستقل لكل خادم.
- **Firestore:** بيانات المستخدمين والفصول ثم لاحقًا باقي بيانات الخدمة.
- **WorkManager:** سيتم استخدامه لاحقًا للمزامنة عند عودة الإنترنت.
- **Admin Dashboard:** سيتم بناؤه لاحقًا كلوحة تحكم Web، وليس كتطبيق Android منفصل.

---

## 2. أين وصلنا؟

### Step 1 — Firebase Integration ✅
تم:
- إضافة `google-services.json`.
- تفعيل Google Services Gradle plugin.
- إضافة Firebase BOM.
- إضافة Firestore.
- ربط المشروع بمشروع Firebase: **Deacons Service** (`deacons-service`).

### Step 2 — Login ✅
تم:
- تفعيل Firebase Authentication / Email & Password.
- إضافة شاشة `LoginScreen`.
- التطبيق يوجه المستخدم إلى Login إذا لم يوجد حساب Firebase مسجل.

### Step 3 — User Profile Infrastructure ✅
تم إضافة:
- `FirebaseUserProfile.kt`
- `FirebaseUserRepository.kt`
- `FirebaseUserSession.kt`

والـProfile الموجود في Firestore تحت:

```text
users/{uid}
```

ويحتوي على:

```text
name
email
role
classId
isActive
```

### Step 4 — Account Session ✅
تم:
- تحميل Profile بعد تسجيل الدخول.
- حفظ الـProfile الحالي في Session.
- معرفة هل المستخدم Admin أو Servant.
- معرفة `classId` الخاص بالخادم.
- رفض الحساب غير المهيأ أو غير النشط.

### Step 5 — Class Validation ✅
تم:
- التأكد من أن الخادم لديه `classId`.
- التأكد من وجود الفصل في Firestore.
- التأكد أن الفصل `isActive = true`.
- منع الدخول إذا كان الفصل غير موجود/غير نشط.
- الـAdmin لا يحتاج إلى `classId`.

---

## 3. Firebase الحالي

### Authentication
يوجد حسابان تم تجهيزهما للاختبار:

1. **Admin** — تم إنشاؤه يدويًا من Firebase Console.
2. **Servant Test Account** — تم إنشاؤه يدويًا من Firebase Console.

لا يتم حفظ كلمات المرور في هذا الملف.

### Firestore
الهيكل الحالي:

```text
users/
  {ADMIN_UID}/
    name
    email
    role = admin
    isActive = true

  {SERVANT_UID}/
    name
    email
    role = servant
    classId = kindergarten
    isActive = true

classes/
  kindergarten/
    name = حضانه
    isActive = true
```

`kindergarten` هو **ID ثابت** للفصل، بينما اسم الفصل المعروض للمستخدم هو `حضانه`.

> الـUIDs الخاصة بالحسابات تم استخدامها أثناء إعداد Firebase، لكن لا يتم وضع كلمات المرور أو أي بيانات دخول سرية داخل المشروع أو README.

---

## 4. Firestore Security Rules الحالية

تم نشر Rules تمنع المستخدم العادي من إعطاء نفسه صلاحيات Admin.

الفكرة الحالية:

- المستخدم المسجل يستطيع قراءة Profile الخاص به.
- الـAdmin يستطيع قراءة Profiles المستخدمين.
- إنشاء/تعديل/حذف Profiles محصور في الـAdmin.
- الـAdmin لديه حاليًا صلاحية كاملة على بقية Firestore مؤقتًا.
- الـServant لا يملك صلاحية على بيانات Firestore العامة حتى يتم تحديد هيكل بيانات الفصول والطلاب والمزامنة.

**هذه القواعد مرحلة انتقالية وليست قواعد النظام النهائي.**

في مرحلة لاحقة سيتم تقييد الخادم ليصل فقط إلى الفصل المسؤول عنه.

---

## 5. هيكل المشروع الحالي

```text
Deacons-Service-Management
│
├── app/
│   ├── google-services.json
│   ├── build.gradle.kts
│   └── src/main/
│       ├── java/com/example/
│       │   ├── MainActivity.kt
│       │   │
│       │   ├── data/
│       │   │   ├── dao/
│       │   │   │   └── AppDaos.kt
│       │   │   │
│       │   │   ├── database/
│       │   │   │   └── DeaconsDatabase.kt
│       │   │   │
│       │   │   ├── firebase/
│       │   │   │   ├── FirebaseUserProfile.kt
│       │   │   │   ├── FirebaseUserRepository.kt
│       │   │   │   └── FirebaseUserSession.kt
│       │   │   │
│       │   │   ├── model/
│       │   │   │   └── Entities.kt
│       │   │   │
│       │   │   └── repository/
│       │   │       └── DeaconsRepository.kt
│       │   │
│       │   ├── ui/
│       │   │   ├── components/
│       │   │   ├── screens/
│       │   │   │   ├── LoginScreen.kt
│       │   │   │   ├── DashboardScreen.kt
│       │   │   │   ├── MembersScreen.kt
│       │   │   │   ├── AttendanceScreen.kt
│       │   │   │   ├── AssessmentsScreen.kt
│       │   │   │   ├── ReportsScreen.kt
│       │   │   │   ├── SettingsScreen.kt
│       │   │   │   ├── MasterDataScreen.kt
│       │   │   │   ├── MemberProfileScreen.kt
│       │   │   │   └── SplashScreen.kt
│       │   │   ├── theme/
│       │   │   └── viewmodel/
│       │   │       └── DeaconsViewModel.kt
│       │   │
│       │   ├── util/
│       │   │   └── ...
│       │   │
│       │   └── workers/
│       │       ├── OverdueCheckWorker.kt
│       │       └── OverdueWorkScheduler.kt
│       │
│       └── res/
│
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/
│       └── gradle-wrapper.properties
│
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

---

## 6. قاعدة البيانات المحلية Room

قاعدة البيانات الحالية اسمها:

```text
deacons_service_database.db
```

ورقم الـRoom Database version الحالي:

```text
7
```

الـEntities الحالية تشمل:

```text
Member
MemberBarcode
VisitRecord
Group
Servant
Attendance
Hymn
HymnAssessment
BibleLesson
BibleAssessment
Exam
ExamResult
AppSetting
EvaluationPeriod
SchoolClass
```

والتطبيق الحالي يحتوي بالفعل على وظائف إدارة الطلاب، الحضور، التقييمات، التقارير، الإعدادات، البيانات الأساسية، الباركود وغيرها.

**لم يتم استبدال Room بـFirebase.**

---

## 7. الفصول الموجودة في التطبيق الأصلي

`DeaconsDatabase.kt` يحتوي على قائمة افتراضية للفصول التالية عند بداية قاعدة البيانات المحلية الفارغة:

```text
أولى ابتدائي
ثانية ابتدائي
ثالثة ابتدائي
رابعة ابتدائي
خامسة ابتدائي
سادسة ابتدائي
أولى إعدادي
ثانية إعدادي
ثالثة إعدادي
أولى ثانوي
ثانية ثانوي
ثالثة ثانوي
```

أما فصل الاختبار الذي تمت إضافته يدويًا في Firebase فهو:

```text
ID: kindergarten
Name: حضانه
```

وتم ربط حساب الخادم التجريبي به.

---

## 8. Dependencies المهمة التي تمت إضافتها/تفعيلها

المشروع يستخدم Firebase BOM، ومعه:

```text
firebase-auth
firebase-firestore
```

وكذلك:

```text
kotlinx-coroutines-play-services
```

للتعامل مع Firebase Tasks باستخدام coroutines.

Room ما زال موجودًا كما هو.

---

## 9. ما لم يتم عمله بعد

هذه أهم الأجزاء المتبقية، بالترتيب المقترح:

### Step 6 — Data Model + Firestore Structure ⏳
تصميم Collections للبيانات الحقيقية، مثل:

```text
classes
members
attendance
visits
assessments
hymns
bible lessons
exams
...
```

وسيتم تحديد العلاقة بين البيانات والفصل.

### Step 7 — Room ↔ Firestore Sync ⏳
الهدف:

```text
                 Firebase
                    ↕
              Sync Engine
                    ↕
                  Room
                    ↕
              Existing UI
```

بحيث الخادم يستطيع العمل بدون إنترنت، وتتم المزامنة تلقائيًا عند عودة الإنترنت.

### Step 8 — Class-based Security ⏳
تقييد الخادم بحيث:

```text
Servant A → Class A فقط
Servant B → Class B فقط
Admin     → كل الفصول
```

### Step 9 — Activity Log ⏳
تسجيل:

- من فعل العملية.
- ماذا فعل.
- على أي طالب/فصل.
- وقت العملية.
- حالة المزامنة.

### Step 10 — Admin Dashboard ⏳
لوحة تحكم Web للإدارة لعرض وإدارة:

- الخدام.
- الفصول.
- الطلاب.
- الحضور.
- الزيارات.
- التقييمات.
- التقارير.
- Activity Log.

### Step 11 — Admin Edits ↔ Servant Apps ⏳
أي تعديل من الـAdmin يصل إلى الأجهزة، مع الحفاظ على الـOffline-first behavior.

### Step 12 — Final Testing + APK ⏳
اختبار:

- Admin Login.
- Servant Login.
- Class restriction.
- Offline work.
- Sync after reconnect.
- Conflict handling.
- Security Rules.
- Admin edits.

ثم إخراج APK النهائي.

---

## 10. قرار معماري مهم

**لن يتم عمل APK مختلف لكل خادم.**

هناك APK واحد للجميع:

```text
                    نفس APK
                       │
             ┌─────────┴─────────┐
             │                   │
           Admin              Servant
             │                   │
       كل البيانات          الفصل المحدد
```

الـUID والـrole والـclassId هي التي تحدد صلاحيات المستخدم.

---

## 11. قواعد العمل في التطوير

- الحفاظ على تصميم وشاشات التطبيق الأصلي قدر الإمكان.
- عدم إزالة أي Feature موجودة بدون قرار واضح.
- Room يظل موجودًا للتشغيل Offline.
- Firebase يضاف كطبقة Cloud/Sync وليس كبديل مباشر لواجهة التطبيق.
- عدم إرسال APK نهائي قبل اكتمال المشروع واختباره.
- التطوير يتم Step-by-Step حتى يتم اعتماد كل مرحلة.

---

## 12. ملاحظة عن الـBuild

النسخة الأصلية التي بدأنا منها لم تكن تحتوي على ملف Gradle Wrapper التنفيذي الكامل (`gradlew`/`gradle-wrapper.jar`). لذلك تم الاحتفاظ بالمشروع الحالي، لكن **لم يتم الادعاء بأن APK تم Build له بنجاح من هذه البيئة**.

الهدف التالي هو تجهيز مسار Build مناسب، ثم إخراج APK بعد اكتمال النظام واختباره.

---

## Current Status

**STEP 5 / 12 تقريبًا — Authentication + Profiles + Class Validation مكتملة.**

الخطوة التالية: **تصميم Firestore Data Model ثم بدء Room ↔ Firebase Sync.**
