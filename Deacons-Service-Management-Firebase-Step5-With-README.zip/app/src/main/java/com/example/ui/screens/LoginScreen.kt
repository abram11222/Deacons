package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.example.data.firebase.FirebaseUserRepository
import com.example.data.firebase.FirebaseUserProfile
import com.example.data.firebase.FirebaseUserSession
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await


private suspend fun isAssignedClassActive(classId: String?): Boolean {
    if (classId.isNullOrBlank()) return false
    val snapshot = FirebaseFirestore.getInstance()
        .collection("classes")
        .document(classId)
        .get()
        .await()
    return snapshot.exists() && snapshot.getBoolean("isActive") == true
}

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
    val auth = remember { FirebaseAuth.getInstance() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (auth.currentUser != null) onLoginSuccess()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "تسجيل الدخول",
            style = MaterialTheme.typography.headlineMedium,
            fontSize = 28.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "إدارة خدمة الشمامسة",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("البريد الإلكتروني") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            enabled = !isLoading
        )
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("كلمة المرور") },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
            visualTransformation = PasswordVisualTransformation(),
            enabled = !isLoading
        )

        errorMessage?.let {
            Spacer(Modifier.height(12.dp))
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                val cleanEmail = email.trim()
                if (cleanEmail.isBlank() || password.isBlank()) {
                    errorMessage = "اكتب البريد الإلكتروني وكلمة المرور"
                    return@Button
                }
                isLoading = true
                auth.signInWithEmailAndPassword(cleanEmail, password)
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            isLoading = false
                            errorMessage = when {
                                task.exception?.message?.contains("password", ignoreCase = true) == true ->
                                    "البريد الإلكتروني أو كلمة المرور غير صحيحة"
                                task.exception?.message?.contains("user", ignoreCase = true) == true ->
                                    "الحساب غير موجود"
                                else -> "تعذر تسجيل الدخول. حاول مرة أخرى."
                            }
                            return@addOnCompleteListener
                        }

                        // Authentication alone is not enough. Every account must
                        // have a centrally managed users/{uid} profile.
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                            try {
                                val profile = FirebaseUserRepository().getCurrentUserProfile()
                                when {
                                    profile == null -> {
                                        auth.signOut()
                                        errorMessage = "الحساب غير مهيأ من الإدارة"
                                    }
                                    !profile.isActive -> {
                                        auth.signOut()
                                        errorMessage = "هذا الحساب غير مفعل حالياً"
                                    }
                                    profile.role != FirebaseUserProfile.ROLE_ADMIN && profile.classId.isNullOrBlank() -> {
                                        auth.signOut()
                                        errorMessage = "الحساب غير مربوط بفصل من الإدارة"
                                    }
                                    profile.role != FirebaseUserProfile.ROLE_ADMIN && !isAssignedClassActive(profile.classId) -> {
                                        auth.signOut()
                                        errorMessage = "الفصل المرتبط بالحساب غير متاح حالياً"
                                    }
                                    else -> {
                                        FirebaseUserSession.setProfile(profile)
                                        onLoginSuccess()
                                    }
                                }
                            } catch (_: Exception) {
                                auth.signOut()
                                errorMessage = "تعذر تحميل بيانات الحساب. تأكد من الإنترنت وحاول مرة أخرى."
                            } finally {
                                isLoading = false
                            }
                        }
                    }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.height(20.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Text("دخول")
            }
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { /* Password reset will be added with account management */ }) {
            Text("نسيت كلمة المرور؟")
        }
    }
}
