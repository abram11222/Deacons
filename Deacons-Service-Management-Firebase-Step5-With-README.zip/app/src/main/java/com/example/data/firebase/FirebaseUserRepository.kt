package com.example.data.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * Reads the cloud profile that controls who the signed-in user is and which
 * class they are assigned to. Room remains the local/offline data source.
 */
class FirebaseUserRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun getCurrentUserProfile(): FirebaseUserProfile? {
        val firebaseUser = auth.currentUser ?: return null
        val snapshot = firestore.collection(COLLECTION_USERS)
            .document(firebaseUser.uid)
            .get()
            .await()

        if (!snapshot.exists()) return null

        return FirebaseUserProfile(
            uid = firebaseUser.uid,
            name = snapshot.getString("name") ?: firebaseUser.displayName.orEmpty(),
            email = snapshot.getString("email") ?: firebaseUser.email.orEmpty(),
            role = snapshot.getString("role") ?: FirebaseUserProfile.ROLE_SERVANT,
            classId = snapshot.getString("classId"),
            isActive = snapshot.getBoolean("isActive") ?: true
        )
    }

    suspend fun saveCurrentUserProfile(profile: FirebaseUserProfile) {
        check(auth.currentUser?.uid == profile.uid) {
            "A user can only write their own profile through this helper."
        }

        firestore.collection(COLLECTION_USERS)
            .document(profile.uid)
            .set(
                mapOf(
                    "name" to profile.name,
                    "email" to profile.email,
                    "role" to profile.role,
                    "classId" to profile.classId,
                    "isActive" to profile.isActive
                )
            )
            .await()
    }

    companion object {
        const val COLLECTION_USERS = "users"
        const val FIELD_ROLE = "role"
        const val FIELD_CLASS_ID = "classId"
    }
}
