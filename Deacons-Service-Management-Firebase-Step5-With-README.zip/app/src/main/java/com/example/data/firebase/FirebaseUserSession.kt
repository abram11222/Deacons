package com.example.data.firebase

/**
 * Lightweight in-memory session for the currently signed-in Firebase user.
 * The actual source of truth remains Firebase Authentication + users/{uid}.
 */
object FirebaseUserSession {
    var profile: FirebaseUserProfile? = null
        private set

    fun setProfile(value: FirebaseUserProfile) {
        profile = value
    }

    fun clear() {
        profile = null
    }

    val isAdmin: Boolean
        get() = profile?.role == FirebaseUserProfile.ROLE_ADMIN

    val assignedClassId: String?
        get() = profile?.classId
}
