package com.example.data.firebase

/**
 * Central identity/profile for a signed-in app user.
 * This is intentionally separate from the existing Room Servant entity.
 */
data class FirebaseUserProfile(
    val uid: String,
    val name: String = "",
    val email: String = "",
    val role: String = ROLE_SERVANT,
    val classId: String? = null,
    val isActive: Boolean = true
) {
    companion object {
        const val ROLE_ADMIN = "admin"
        const val ROLE_SERVANT = "servant"
    }
}
